"""Phase-1 pipeline: discover -> enrich -> score -> rank top wallets.

Free seed (Hyperliquid stats leaderboard) + native info API enrichment +
risk-adjusted scoring. Outputs CSV/JSON. Postgres writer is an optional stub.
"""
from __future__ import annotations
import csv
import json
import argparse
from dataclasses import dataclass, field

from hl_client import HyperliquidClient
from scoring import metrics_from_portfolio, metrics_from_fills, composite_scores


@dataclass
class Config:
    window: str = "month"            # 30-day window
    top_n: int = 50                  # final ranking size
    candidate_pool: int = 200        # how many seed wallets to enrich
    min_account_value: float = 50_000.0
    min_trades_30d: int = 20
    require_positive_roi: bool = True
    shrink_k: int = 20
    throttle_s: float = 0.4
    weights: dict = field(default_factory=lambda: {
        "calmar": 0.35, "sharpe_like": 0.25, "roi_30d": 0.20, "profit_factor": 0.20})


def _window_perf(row: dict, window: str) -> dict:
    for name, obj in row.get("windowPerformances", []):
        if name == window:
            return {"pnl": float(obj["pnl"]), "roi": float(obj["roi"]), "vlm": float(obj["vlm"])}
    return {"pnl": 0.0, "roi": 0.0, "vlm": 0.0}


def select_candidates(rows: list[dict], cfg: Config) -> list[dict]:
    """Pre-filter the seed and take the top candidate pool by window ROI."""
    cands = []
    for r in rows:
        av = float(r.get("accountValue", 0) or 0)
        if av < cfg.min_account_value:
            continue
        wp = _window_perf(r, cfg.window)
        if wp["vlm"] <= 0:
            continue
        if cfg.require_positive_roi and wp["roi"] <= 0:
            continue
        cands.append({"address": r["ethAddress"], "seed_account_value": av,
                      "seed_roi": wp["roi"], "seed_pnl": wp["pnl"], "seed_vlm": wp["vlm"]})
    cands.sort(key=lambda c: c["seed_roi"], reverse=True)
    return cands[: cfg.candidate_pool]


def enrich_and_score(client: HyperliquidClient, candidates: list[dict], cfg: Config) -> list[dict]:
    scored = []
    for i, c in enumerate(candidates, 1):
        addr = c["address"]
        try:
            pf = client.portfolio(addr)
            pm = metrics_from_portfolio(pf, cfg.window)
            if not pm:
                continue
            fills = client.user_fills(addr)
            fm = metrics_from_fills(fills, window_days=30)
            row = {**c, **pm, **fm}
            # hard gates
            if row["n_trades_30d"] < cfg.min_trades_30d:
                continue
            if cfg.require_positive_roi and row["roi_30d"] <= 0:
                continue
            if row["vol_period"] <= 0:
                continue
            scored.append(row)
        except Exception as e:
            print(f"[{i}/{len(candidates)}] skip {addr[:10]}…: {e}")
        if i % 25 == 0:
            print(f"  enriched {i}/{len(candidates)} | kept {len(scored)}")
    return scored


def run(cfg: Config, out_prefix: str = "top_wallets") -> list[dict]:
    client = HyperliquidClient(throttle_s=cfg.throttle_s)
    print("fetching free leaderboard seed…")
    rows = client.leaderboard()
    print(f"  {len(rows)} wallets in seed")
    cands = select_candidates(rows, cfg)
    print(f"  {len(cands)} candidates after pre-filter (≥${cfg.min_account_value:,.0f}, +ROI)")
    scored = enrich_and_score(client, cands, cfg)
    scored = composite_scores(scored, weights=cfg.weights, shrink_k=cfg.shrink_k)
    scored.sort(key=lambda r: r["score"], reverse=True)
    top = scored[: cfg.top_n]
    _write_outputs(top, out_prefix)
    return top


def _write_outputs(top: list[dict], prefix: str) -> None:
    if not top:
        print("no wallets passed the filters")
        return
    cols = ["address", "score", "score_shrink_factor", "roi_30d", "calmar", "sharpe_like",
            "max_drawdown_frac", "win_rate", "profit_factor", "n_trades_30d",
            "pnl_30d", "realized_pnl_30d", "start_account_value", "seed_vlm"]
    with open(f"{prefix}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(top)
    with open(f"{prefix}.json", "w") as f:
        json.dump(top, f, indent=2)
    print(f"wrote {prefix}.csv and {prefix}.json ({len(top)} rows)")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--top", type=int, default=50)
    p.add_argument("--pool", type=int, default=200)
    p.add_argument("--min-av", type=float, default=50_000)
    p.add_argument("--min-trades", type=int, default=20)
    p.add_argument("--throttle", type=float, default=0.4)
    p.add_argument("--out", type=str, default="top_wallets")
    a = p.parse_args()
    cfg = Config(top_n=a.top, candidate_pool=a.pool, min_account_value=a.min_av,
                 min_trades_30d=a.min_trades, throttle_s=a.throttle)
    run(cfg, out_prefix=a.out)
