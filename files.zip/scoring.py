"""Risk-adjusted scoring for Hyperliquid wallets.

Core idea: a raw PnL/ROI leaderboard rewards high-leverage luck and survivorship.
We recompute returns from the deposit-insensitive cumulative-PnL curve, measure
risk (drawdown, volatility), and shrink scores for small trade samples.
"""
from __future__ import annotations
import math
import time
from typing import Optional

MS_PER_DAY = 86_400_000


def _series_from_portfolio(portfolio: list, period: str = "month") -> tuple[list, list]:
    """Return (accountValueHistory, pnlHistory) for a period as lists of (ts, float)."""
    avh, pnlh = [], []
    for name, obj in portfolio:
        if name == period:
            avh = [(int(t), float(v)) for t, v in obj.get("accountValueHistory", [])]
            pnlh = [(int(t), float(v)) for t, v in obj.get("pnlHistory", [])]
    return avh, pnlh


def _max_drawdown(curve: list[float]) -> float:
    """Max peak-to-trough drop on a cumulative curve, in absolute units."""
    peak = curve[0]
    mdd = 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = max(mdd, peak - v)
    return mdd


def metrics_from_portfolio(portfolio: list, period: str = "month") -> Optional[dict]:
    """Risk metrics derived from the PnL curve (deposit-insensitive)."""
    avh, pnlh = _series_from_portfolio(portfolio, period)
    if len(pnlh) < 5 or len(avh) < 2:
        return None
    start_av = avh[0][1]
    if start_av <= 0:
        return None

    cum = [v for _, v in pnlh]
    ts = [t for t, _ in pnlh]
    pnl_window = cum[-1] - cum[0]
    roi_window = pnl_window / start_av

    # period returns normalized by starting equity
    rets = [(cum[i] - cum[i - 1]) / start_av for i in range(1, len(cum))]
    n = len(rets)
    mean_r = sum(rets) / n
    var_r = sum((x - mean_r) ** 2 for x in rets) / n
    std_r = math.sqrt(var_r)

    span_days = max((ts[-1] - ts[0]) / MS_PER_DAY, 1e-9)
    periods_per_year = n / span_days * 365.0
    sharpe_like = (mean_r / std_r * math.sqrt(periods_per_year)) if std_r > 0 else 0.0

    mdd_abs = _max_drawdown(cum)
    mdd_frac = mdd_abs / start_av
    calmar = (roi_window / mdd_frac) if mdd_frac > 1e-9 else (roi_window * 10 if roi_window > 0 else 0.0)

    return {
        "start_account_value": start_av,
        "pnl_30d": pnl_window,
        "roi_30d": roi_window,
        "vol_period": std_r,
        "sharpe_like": sharpe_like,
        "max_drawdown_frac": mdd_frac,
        "calmar": calmar,
        "curve_points": len(cum),
    }


def metrics_from_fills(fills: list, window_days: int = 30) -> dict:
    """Trade-quality metrics from closing fills within the window."""
    cutoff = int(time.time() * 1000) - window_days * MS_PER_DAY
    closes = [f for f in fills
              if int(f.get("time", 0)) >= cutoff and float(f.get("closedPnl", 0) or 0) != 0.0]
    wins = [f for f in closes if float(f["closedPnl"]) > 0]
    losses = [f for f in closes if float(f["closedPnl"]) < 0]
    gp = sum(float(f["closedPnl"]) for f in wins)
    gl = abs(sum(float(f["closedPnl"]) for f in losses))
    n = len(closes)
    return {
        "n_trades_30d": n,
        "win_rate": (len(wins) / n) if n else 0.0,
        "profit_factor": (gp / gl) if gl > 0 else (gp and 10.0 or 0.0),
        "realized_pnl_30d": gp - gl,
        "fees_30d": sum(float(f.get("fee", 0) or 0) for f in closes),
        "fills_seen": len(fills),
    }


def _percentile_ranks(values: list[float]) -> list[float]:
    """Map values to [0,1] percentile ranks (ties share average rank)."""
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    for pos, idx in enumerate(order):
        ranks[idx] = pos / max(len(values) - 1, 1)
    return ranks


def composite_scores(rows: list[dict],
                     weights: Optional[dict] = None,
                     shrink_k: int = 20) -> list[dict]:
    """Add a 0-100 composite score to each row, computed within the candidate pool.

    Blends percentile ranks of calmar / sharpe / roi / profit_factor, then
    multiplies by a sample-size shrinkage factor n/(n+k) to discount lucky
    low-trade accounts.
    """
    if not rows:
        return rows
    w = weights or {"calmar": 0.35, "sharpe_like": 0.25, "roi_30d": 0.20, "profit_factor": 0.20}
    pr = {k: _percentile_ranks([r.get(k, 0.0) for r in rows]) for k in w}
    for i, r in enumerate(rows):
        base = sum(w[k] * pr[k][i] for k in w)
        shrink = r["n_trades_30d"] / (r["n_trades_30d"] + shrink_k)
        r["score"] = round(100 * base * shrink, 2)
        r["score_shrink_factor"] = round(shrink, 3)
    return rows
