"""Thin Hyperliquid data client: free stats leaderboard + native info API.

Only public, read-only endpoints. Rate-limit aware (info endpoints are the
constrained bucket; most weigh 20 units → ~60 calls/min).
"""
from __future__ import annotations
import time
import requests
from typing import Any

INFO_URL = "https://api.hyperliquid.xyz/info"
STATS_LEADERBOARD_URL = "https://stats-data.hyperliquid.xyz/Mainnet/leaderboard"


class HyperliquidClient:
    def __init__(self, throttle_s: float = 0.4, timeout: int = 30):
        # throttle_s: pause between info calls to stay under the weight cap
        self.throttle_s = throttle_s
        self.timeout = timeout
        self._session = requests.Session()
        self._last_info_call = 0.0

    # ---- free discovery seed ----
    def leaderboard(self) -> list[dict]:
        """Full native stats leaderboard (~38k rows). One large GET, not info-weighted."""
        r = self._session.get(STATS_LEADERBOARD_URL, timeout=self.timeout)
        r.raise_for_status()
        return r.json().get("leaderboardRows", [])

    # ---- per-wallet enrichment (info API) ----
    def _info(self, payload: dict) -> Any:
        # simple client-side throttle
        wait = self.throttle_s - (time.time() - self._last_info_call)
        if wait > 0:
            time.sleep(wait)
        r = self._session.post(INFO_URL, json=payload, timeout=self.timeout)
        self._last_info_call = time.time()
        r.raise_for_status()
        return r.json()

    def clearinghouse_state(self, address: str) -> dict:
        return self._info({"type": "clearinghouseState", "user": address})

    def portfolio(self, address: str) -> list:
        return self._info({"type": "portfolio", "user": address})

    def user_fills(self, address: str) -> list:
        return self._info({"type": "userFills", "user": address})
