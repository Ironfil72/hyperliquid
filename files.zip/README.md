# hl_alpha — Hyperliquid top-wallet analysis (Fase 1)

Discovery → arricchimento → scoring risk-adjusted → ranking dei migliori wallet
su Hyperliquid. Solo endpoint pubblici e gratuiti.

## Componenti
- `hl_client.py` — client API (stats leaderboard gratuita + info API nativa, rate-limit aware)
- `scoring.py` — metriche risk-adjusted dalla curva di PnL e dai fill
- `pipeline.py` — orchestrazione discovery → enrich → score → rank, output CSV/JSON

## Avvio
```bash
pip install -r requirements.txt
python pipeline.py --top 50 --pool 200 --min-av 50000 --min-trades 20 --out top_wallets
```

## Knob principali (Config in pipeline.py)
- `window`        finestra performance (default "month" = 30 giorni)
- `top_n`         dimensione ranking finale (50)
- `candidate_pool`  quanti wallet del seed arricchire prima dello scoring (200)
- `min_account_value` filtro account value minimo (50.000$)
- `min_trades_30d`  trade minimi a 30g, gate anti-fortuna (20)
- `shrink_k`      forza dello shrinkage per campioni piccoli (20)
- `throttle_s`    pausa tra chiamate info, per i rate limit (0.4s)

## Cosa significa lo `score` (0–100)
Blend di rank percentile su Calmar, Sharpe-like, ROI 30g e profit factor,
moltiplicato per uno shrinkage n/(n+k) che penalizza chi ha pochi trade.
I rendimenti sono calcolati dalla curva di **PnL cumulato** (insensibile a
depositi/prelievi), non dall'account value.

## Note e raffinamenti (Fase 1.5)
- `max_drawdown_frac` è normalizzato sull'equity iniziale: per conti molto
  cresciuti può superare il 100%. Refinement: normalizzare sul peak running.
- Alcuni trader si escludono dalla leaderboard pubblica → seed incompleto.
  In Fase 2: aggiungere fonte a pagamento (Nansen Smart Money) o scraping.

## Hook Fase 2 (pipeline completa)
- Persistenza: writer Postgres (storico ranking, per trend e backtest del segnale)
- n8n: scheduling del polling + alert Telegram sulle nuove posizioni delle top wallet
- Copy-signal: confronto snapshot posizioni (clearinghouseState) tra run consecutivi
